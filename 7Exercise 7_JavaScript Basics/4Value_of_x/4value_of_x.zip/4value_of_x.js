/*
var color = 'green';
var name = 'toli';
var longName = name.length > 5;
var colorStartsWithg = color[1] === "g";
var x = longName && colorStartsWithg;
console.log("x = " + x);




var life = "is great";
var char = life[3];
console.log("char = " + char);
*/


var bool = "soft" === "hard" || 6 > 5 && 2 === 1 + 1;
console.log("bool  =  " + bool );