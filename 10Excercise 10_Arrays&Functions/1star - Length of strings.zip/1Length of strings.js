
function getLenghtOfStrings(arr) {
    var newArr = [];
    for (var i = 0; i < arr.length; i++) {
      newArr.push(arr[i].length);
    }
    return newArr;
  }
  
  function test_equal(actual, expected, msg) {
      if (Array.isArray(expected)) {
      for (var i = 0; i < expected.length; i++){
      test_equal(actual[i], expected[i], "item in index " + i);
      }
      } else {
      if (actual !== expected) {
      console.log(`Error testing ${msg || ''}. expected: ${expected}, got ${actual}`)
      }
      }
      }
      test_equal(getLenghtOfStrings(["one", "two", "three"]), [3,3,5]);
      test_equal(getLenghtOfStrings(["a", "ab", "abc"]), [1,2,3]);
      test_equal(getLenghtOfStrings(["", "go", ""]), [0,2,0]);
      test_equal(getLenghtOfStrings(["alone"]),[5]);