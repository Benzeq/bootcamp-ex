(x, y) => x > y ? x : y;

(boot, bootCamp) => boot.includes(bootCamp)


