function ageCheck() {
  var age = document.getElementById("user-age").value;
  var answer = document.getElementById("answer");

  if (age > 18) {
      answer.innerText  = "You can drink!";
  } else {
      answer.innerText = "Go home, Kid!";
  }
};
