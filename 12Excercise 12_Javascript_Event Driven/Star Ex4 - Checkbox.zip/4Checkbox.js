function on() {
  var checking = document.getElementById("checker");
  var image = document.getElementById("pic");

  if (checking.checked) {
    image.style.display = "block";
  } else {
    image.style.display = "none";
  }
}
