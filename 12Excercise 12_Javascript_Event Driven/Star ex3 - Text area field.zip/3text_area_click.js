function userText() {
    var a = document.getElementById("area").value;
    var b = document.getElementById("answer");

    if (a.length < 100) {
        b.innerHTML = "please enter at least 100 characters";      
    } else {
        b.innerHTML = "massage sent :)"
    }
}