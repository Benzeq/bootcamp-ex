function afterClick() {
  var userWelcome = document.getElementById("user-name").value;
  console.log("Hello " + userWelcome);
}
