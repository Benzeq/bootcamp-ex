var book = {
  name: "theCode",
  author: "codeMan",
  publisher: "toastBook",
  year: 2019,
  genre: "comedy"
};

function getBookDescription() {
    return "the book " + book.name + " was written by " + book.author + "in the year " + book.year;    
};


getBookDescription();
