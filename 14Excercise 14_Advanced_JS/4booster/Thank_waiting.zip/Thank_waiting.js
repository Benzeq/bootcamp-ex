setTimeout(freeze, 6000);

function freeze() {
    var msg = document.createElement("p");
    msg.innerText = "6 seconds that worth it all!";
    document.body.appendChild(msg);
}










