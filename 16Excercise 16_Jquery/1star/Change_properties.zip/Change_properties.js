//1
$('.link').css('font-family', 'Courier New');

//2
$(".link:nth-child(3)").css("color", "Salmon");

//3
$("body").css("background-color", "lightblue");